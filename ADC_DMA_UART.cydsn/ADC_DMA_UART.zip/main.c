/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

#define BUFFERSIZE 1000

volatile uint8 adc_dma_array_full = 0;
volatile uint8 adc_dma_array_bussy = 1;
volatile uint8 adc_dma_array_1_full = 0;
volatile uint8 adc_dma_array_1_bussy = 0;
volatile uint8 adc_dma_array_2_full = 0;
volatile uint8 adc_dma_array_2_bussy = 0;

uint8 dataReady = 0u;
uint16 result;
uint8 adc_dma_array[BUFFERSIZE];
uint8 adc_dma_array_1[BUFFERSIZE];
uint8 adc_dma_array_2[BUFFERSIZE];

volatile uint8 fault = 0;

volatile uint16 counter_flip = 0;

CY_ISR(DmaDone)
{
    if((adc_dma_array_full == 1) & (adc_dma_array_1_full == 1) & (adc_dma_array_2_full == 1)) {
        fault = 1;
    } else if(adc_dma_array_bussy == 1) {
        adc_dma_array_full = 1;       
        adc_dma_array_bussy = 0;
        adc_dma_array_1_bussy = 1;
    } else if(adc_dma_array_1_bussy == 1) {
        adc_dma_array_1_full = 1;
        adc_dma_array_1_bussy = 0;
        adc_dma_array_2_bussy = 1;
    } else if(adc_dma_array_2_bussy == 1) {
        adc_dma_array_2_full = 1;
        adc_dma_array_2_bussy = 0;
        adc_dma_array_bussy = 1;
    }
}

CY_ISR(Timer_ISR)
{
    counter_flip++;
}

void sendData(uint8 *data) {
            //Timer_1_Enable();
            char t[5];
            for(uint16 i=0; i < BUFFERSIZE; i++) {
                //sprintf(t, "%d", data[i]);
                UART_1_WriteTxData(data[i]);
                //UART_1_WriteTxData(test);
                //UART_1_WriteTxData(test<<8);
                //UART_1_PutString(t);
                //UART_1_PutString("\r\n");
                //UART_1_PutChar(adc_dma_array[i] & 0xFF);
                //UART_1_PutChar(adc_dma_array[i] >> 8);
                
                //UART_1_PutString("\r\n");
                
            }
            //UART_1_PutString("\r\n");
        
            //Timer_1_Stop();
            
            //uint16 counter_value = Timer_1_ReadCounter();
            //uint16 time_ms = ((Timer_1_ReadPeriod()+1) * counter_flip + counter_value) / 24000;
            //sprintf(t, "%d", time_ms);
            //UART_1_PutString(t);
            //UART_1_PutString("\r\n");
            //counter_flip = 0;
            
}

int main(void)
{
    uint8 adc_result = 0;
    
    Timer_1_Init();
    isr_timer_StartEx(Timer_ISR);
    
    /* Defines for DMA_1 */
    #define DMA_1_BYTES_PER_BURST 1
    #define DMA_1_REQUEST_PER_BURST 1
    #define DMA_1_SRC_BASE (CYDEV_PERIPH_BASE)
    #define DMA_1_DST_BASE (CYDEV_SRAM_BASE)

    /* Variable declarations for DMA_1 */
    /* Move these variable declarations to the top of the function */
    uint8 DMA_1_Chan;
    uint8 DMA_1_TD[3]; // CHANGED TO 3

    /* DMA Configuration for DMA_1 */
    DMA_1_Chan = DMA_1_DmaInitialize(DMA_1_BYTES_PER_BURST, DMA_1_REQUEST_PER_BURST, 
        HI16(DMA_1_SRC_BASE), HI16(DMA_1_DST_BASE));
    DMA_1_TD[0] = CyDmaTdAllocate();
    DMA_1_TD[1] = CyDmaTdAllocate(); // ADDED THIS LINE
    DMA_1_TD[2] = CyDmaTdAllocate(); // ADDED THIS LINE
    CyDmaTdSetConfiguration(DMA_1_TD[0], BUFFERSIZE * DMA_1_BYTES_PER_BURST, DMA_1_TD[1], DMA_1__TD_TERMOUT_EN | CY_DMA_TD_INC_DST_ADR); // CHANED NEXTD TO [1]
    CyDmaTdSetConfiguration(DMA_1_TD[1], BUFFERSIZE * DMA_1_BYTES_PER_BURST, DMA_1_TD[2], DMA_1__TD_TERMOUT_EN | CY_DMA_TD_INC_DST_ADR); // ADDED THIS LINE
    CyDmaTdSetConfiguration(DMA_1_TD[2], BUFFERSIZE * DMA_1_BYTES_PER_BURST, DMA_1_TD[0], DMA_1__TD_TERMOUT_EN | CY_DMA_TD_INC_DST_ADR); // ADDED THIS LINE
    CyDmaTdSetAddress(DMA_1_TD[0], LO16((uint32)ADC_SAR_1_SAR_WRK0_PTR), LO16((uint32)adc_dma_array));
    CyDmaTdSetAddress(DMA_1_TD[1], LO16((uint32)ADC_SAR_1_SAR_WRK0_PTR), LO16((uint32)adc_dma_array_1)); // ADDED THIS LINE
    CyDmaTdSetAddress(DMA_1_TD[2], LO16((uint32)ADC_SAR_1_SAR_WRK0_PTR), LO16((uint32)adc_dma_array_2)); // ADDED THIS LINE
    CyDmaChSetInitialTd(DMA_1_Chan, DMA_1_TD[0]);
    CyDmaChEnable(DMA_1_Chan, 1);

    /* Setup the Interrupt connected to the nrq terminal. */
    isr_dma_StartEx(DmaDone);
    
    UART_1_Start();
    //UART_1_PutString("Starting...\r\n");
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    ADC_SAR_1_Start(); // Function calls init function of not done yet and enable the ADC
    
    ADC_SAR_1_StartConvert();
    //CyDelay(10);
    //PWM_1_Start();
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    for(;;)
    {
        if(fault == 1) {
            while(1){
                UART_1_PutString("All full\r\n");
                CyDelay(1000);
            }
        }
        if(adc_dma_array_full) {
            sendData(adc_dma_array);
            //UART_1_PutString("full\r\n");
            adc_dma_array_full = 0;
        } else if(adc_dma_array_1_full) {
            sendData(adc_dma_array_1);
            //UART_1_PutString("full_1\r\n");
            adc_dma_array_1_full = 0;
        } else if(adc_dma_array_2_full) {
            sendData(adc_dma_array_2);
            //UART_1_PutString("full_2\r\n");
            adc_dma_array_2_full = 0;
        }

        /* Place your application code here. */
        
    }
}
/* [] END OF FILE */
